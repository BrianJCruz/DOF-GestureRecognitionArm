#include "ServoArm.h"

	
	ServoArm::ServoArm(uint8_t basePin = 2, uint8_t shoulderPin = 3, uint8_t elbowPin = 4, uint8_t wristPin = 10, uint8_t gripperPin = 11, uint8_t wristRotatePin = 12) {
	  
	  this->basePin = basePin;
	  this->shoulderPin = shoulderPin;
	  this->elbowPin = elbowPin;
	  this->wristPin = wristPin;
	  this->gripperPin = gripperPin;
	  this->wristRotatePin = wristRotatePin;
	  
	}
    
    // Rotate the Servo base. Speed is defined in miliseconds
    void ServoArm::moveBase(int angle, int movSpeed = 35) {

      if (angle >= initBasePosition) {
        for ( int pos = initBasePosition; pos <= angle; pos += 1 ) {
          baseServo.write(pos);
          delay(movSpeed);
        }
        
      } else if (angle <= initBasePosition) {  
          for ( int pos = initBasePosition; pos >= angle; pos -= 1 ) {     
            baseServo.write(pos);
            delay(movSpeed);
          }
      }

      initBasePosition = angle;
      
    }

    void ServoArm::moveShoulder(int angle, int movSpeed = 35) {

      if (angle >= initShoulderPos) {
        for ( int pos = initShoulderPos; pos <= angle; pos += 1 ) {
          shoulderServo.write(pos);
          delay(movSpeed);
        }
        
      } else if (angle <= initShoulderPos) {  
          for ( int pos = initShoulderPos; pos >= angle; pos -= 1 ) {     
            shoulderServo.write(pos);
            delay(movSpeed);
          }
      }

      initShoulderPos = angle;
    }

    void ServoArm::moveElbow(int angle, int movSpeed = 35) {

      if (angle >= initElbowPos) {
        for ( int pos = initElbowPos; pos <= angle; pos += 1 ) {
          elbowServo.write(pos);
          delay(movSpeed);
        }
        
      } else if (angle <= initElbowPos) {  
          for ( int pos = initElbowPos; pos >= angle; pos -= 1 ) {     
            elbowServo.write(pos);
            delay(movSpeed);
          }
      }

      initElbowPos = angle;
    }

    void ServoArm::moveWrist(int angle, int movSpeed = 35) {

      if (angle >= initWristPos) {
        for ( int pos = initWristPos; pos <= angle; pos += 1 ) {
          wristServo.write(pos);
          delay(movSpeed);
        }
        
      } else if (angle <= initWristPos) {  
          for ( int pos = initWristPos; pos >= angle; pos -= 1 ) {     
            wristServo.write(pos);
            delay(movSpeed);
          }
      }

      initWristPos = angle;
    }

    void ServoArm::moveGripper(int angle, int movSpeed = 35) {

      if (angle >= initGripperPos) {
        for ( int pos = initGripperPos; pos <= angle; pos += 1 ) {
          gripperServo.write(pos);
          delay(movSpeed);
        }
        
      } else if (angle <= initGripperPos) {  
          for ( int pos = initGripperPos; pos >= angle; pos -= 1 ) {     
            gripperServo.write(pos);
            delay(movSpeed);
          }
      }

      initGripperPos = angle;
    }

    void ServoArm::moveWristR(int angle, int movSpeed = 35) {

      if (angle >= initWristRPos) {
        for ( int pos = initWristRPos; pos <= angle; pos += 1 ) {
          wristRotateServo.write(pos);
          delay(movSpeed);
        }
        
      } else if (angle <= initWristRPos) {  
          for ( int pos = initWristRPos; pos >= angle; pos -= 1 ) {     
            wristRotateServo.write(pos);
            delay(movSpeed);
          }
      }

      initWristRPos = angle;
    }

    void ServoArm::moveAll(int angle, int freq = 1000) {
        
      moveBase(angle);
      delay(freq);
      moveShoulder(angle);
      delay(freq);
      moveElbow(angle);
      delay(freq);
      moveWrist(angle);
      delay(freq);
      moveGripper(angle);
      delay(freq);
      moveWristR(angle);
      
      
    }

    void ServoArm::getObjectLeft(){

      moveBase(40);
      delay(1000);
      moveElbow(100);
      delay(1000);
      moveWrist(35);
      delay(1000);
      moveGripper(10);
      delay(1000);
      moveShoulder(60);
      delay(1000);
      moveGripper(90);
      delay(1000);
      moveShoulder(90);
      delay(1000);
      moveBase(90);
      delay(1000);
      moveShoulder(60);
      delay(1000);
      moveGripper(0);
      delay(1000);
      moveShoulder(90);
      delay(1000);
      moveAll(90);
      delay(1000);
      
      
    }
